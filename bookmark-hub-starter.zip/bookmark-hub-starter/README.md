# Bookmark Hub Starter

A production-clean starter for a bookmark manager / dashboard app using:

- FastAPI
- SQLAlchemy 2.x
- Alembic
- Jinja2 + HTMX
- SQLite
- Python logging
- Dev Containers
- GitHub Copilot instructions

## Quick start

### Option 1: Dev Container
Open the repo in VS Code and reopen in the provided dev container.

### Option 2: Local

```bash
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows PowerShell
pip install -e .[dev]
cp .env.example .env
alembic upgrade head
uvicorn app.main:app --reload
```

Open:
- App: http://127.0.0.1:8000
- Swagger: http://127.0.0.1:8000/docs

## Project structure

```text
app/
  api/routes/        # FastAPI endpoints
  db/models/         # SQLAlchemy ORM models
  repositories/      # Data access
  schemas/           # Pydantic request/response models
  services/          # Business logic
  templates/         # Jinja2 templates
  static/            # Static assets
```

## Commands

```bash
ruff check .
black .
pytest
```
